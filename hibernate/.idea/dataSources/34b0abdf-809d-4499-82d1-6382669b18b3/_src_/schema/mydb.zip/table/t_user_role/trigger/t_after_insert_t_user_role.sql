CREATE TRIGGER `t_after_insert_t_user_role`
AFTER INSERT ON `t_user_role`
FOR EACH ROW
  BEGIN
     insert into act_id_membership(user_id_,group_id_) values(new.user_id,new.role_id);
END