CREATE TRIGGER `t_after_insert_t_user`
AFTER INSERT ON `t_user`
FOR EACH ROW
  BEGIN
     insert into act_id_user(id_,rev_,first_,pwd_) values(new.id,1,new.username,new.password);
END