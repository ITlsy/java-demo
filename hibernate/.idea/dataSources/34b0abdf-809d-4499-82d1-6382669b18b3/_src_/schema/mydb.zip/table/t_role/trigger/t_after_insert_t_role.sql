CREATE TRIGGER `t_after_insert_t_role`
AFTER INSERT ON `t_role`
FOR EACH ROW
  BEGIN
     insert into act_id_group(id_,rev_,name_) values(new.id,1,new.view_name);
END