CREATE TRIGGER `stu_insert_after`
AFTER INSERT ON `t_stu`
FOR EACH ROW
  insert into t_school(schoolname) values(new.username)