CREATE TRIGGER `stu_delete_before`
BEFORE DELETE ON `t_school`
FOR EACH ROW
  begin
delete from username where stu_id=old.id;
end