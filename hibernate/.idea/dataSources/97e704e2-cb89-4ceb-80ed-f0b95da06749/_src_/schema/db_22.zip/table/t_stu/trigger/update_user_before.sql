CREATE TRIGGER `update_user_before`
BEFORE UPDATE ON `t_stu`
FOR EACH ROW
  begin
set new.username=upper(new.username);
update t_school set schoolname=new.username where schoolname=old.username;
end