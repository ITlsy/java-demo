CREATE VIEW `v_customers_3` AS
  SELECT `v_customers_2`.`地址` AS `地址`
  FROM `db_22`.`v_customers_2`