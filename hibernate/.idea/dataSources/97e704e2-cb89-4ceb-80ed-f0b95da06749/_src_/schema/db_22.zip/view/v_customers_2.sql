CREATE VIEW `v_customers_2` AS
  SELECT
    `db_22`.`customers`.`cust_name`    AS `名称`,
    `db_22`.`customers`.`cust_address` AS `地址`
  FROM `db_22`.`customers`