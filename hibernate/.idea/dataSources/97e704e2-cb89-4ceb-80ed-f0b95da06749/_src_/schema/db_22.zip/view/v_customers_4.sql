CREATE VIEW `v_customers_4` AS
  SELECT
    `db_22`.`customers`.`cust_id`      AS `cust_id`,
    `db_22`.`customers`.`cust_name`    AS `cust_name`,
    `db_22`.`customers`.`cust_address` AS `cust_address`,
    `db_22`.`customers`.`cust_city`    AS `cust_city`,
    `db_22`.`customers`.`cust_state`   AS `cust_state`,
    `db_22`.`customers`.`cust_zip`     AS `cust_zip`,
    `db_22`.`customers`.`cust_country` AS `cust_country`,
    `db_22`.`customers`.`cust_contact` AS `cust_contact`,
    `db_22`.`customers`.`cust_email`   AS `cust_email`
  FROM `db_22`.`customers`
  ORDER BY `db_22`.`customers`.`cust_id` DESC