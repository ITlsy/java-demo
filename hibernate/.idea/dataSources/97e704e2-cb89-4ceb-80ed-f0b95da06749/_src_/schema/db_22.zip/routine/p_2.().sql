CREATE PROCEDURE `p_2`()
  BEGIN
select max(prod_price) into maxP from products;
select min(prod_price) into minP from products;
END