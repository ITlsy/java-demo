CREATE PROCEDURE `p_4`(`cname` VARCHAR(20))
  begin
INSERT INTO customers(cust_name)
VALUES(cname);
end