CREATE PROCEDURE `p_3`(`cid` INT(11))
  begin 
select * from customers where cust_id=cid;
end